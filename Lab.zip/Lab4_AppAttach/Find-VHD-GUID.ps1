﻿$VolumeGuid = (((Get-Volume -DriveLetter x).UniqueId).split('{')[1]).split('}')[0]
$VolumeGuid