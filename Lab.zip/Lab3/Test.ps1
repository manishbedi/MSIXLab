﻿New-Item -Path $env:APPDATA\ -Name "Test" -ItemType "directory"


New-Item $env:APPDATA\Test\test.txt


Set-Content $env:APPDATA\Test\test.txt 'Welcome to MSIX'
